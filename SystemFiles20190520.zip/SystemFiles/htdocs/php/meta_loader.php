<?php
	echo'<link rel="stylesheet" href="../css/styles.css">' .
		' <meta charset="UTF-8">';
?>