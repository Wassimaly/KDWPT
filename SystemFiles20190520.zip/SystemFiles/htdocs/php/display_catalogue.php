<?php
include('selection_class.php');
@session_start();
function create_table() {

	require_once('../connect.php');
	$library = $_SESSION['library'];
	$query = "CALL GetLibrary ('$library')";
	$results = array();
	$response = @mysqli_query($dbc,$query);
	if($response){
		echo '<div class="container">';
		echo '<table class="searchable sortable"><thead>
		<tr><th>Name</th>
		<th>Description</th>
		<th>Media Type</th>
		<th>Subject Type</th>
		<th> Check out Date </th>
		<th> Return Date </th>
		<th> Check Out</th>
		
		</tr></thead>';
		$count=0;
		$selCount = 0;
		while($row = mysqli_fetch_array($response)){
			$results[] = $row;
			echo '<tr><td>' .
			$row['TypeName'] . '</td><td>' .
			$row['description'] . '</td><td>' .
			$row['media'] . '</td><td>' .
			$row['TypeSubject'] . '</td><td>' ;
			echo '<input type="date" name="dateOut' . 
			$count . '" id="dateOut' . $count . '"></td><td>' ;		
			echo '<input type="date" name="dateIn' .
			$count . '" id="dateIn' . $count . '"></td><td class="checkbox">'; 
			echo '<input type="checkbox" name="' .
			$row['itemTypeID'] . '"';
			
/*			if(isset($_SESSION['Selections'])){
				foreach($_SESSION['Selections'] as $ID){
					$selCount++;
					if($row['itemTypeID'] == $ID->itemType){
							echo ' checked';
							unset($ID);
							break 1;
					}
				}
			}
*/
			echo '></td>'  ;
			$count++;
		}
		$_SESSION['itemTypeList'] = $results;
		echo '</table></div>';
		echo '<br><div class="center"><button type="submit" name="submit" id="submit" disabled>Make Selection</button></div></form>';
		//echo '<br>Number of times Selection check run: ' . $selCount;
	}	
	else{
	echo 'Could not complete database query.';
	echo mysqli_error($dbc);

	}
mysqli_close($dbc);
if(isset($_POST['submit'])){	
header('Location:../pages/verify_selection.php');
	save_selection(false);
	
/*	echo 'SELECTION LIST<br>';
	foreach($_SESSION['Selections'] as $row){
		echo $row->itemType . ' selected for ' . $row->checkOut . ' to ' . $row->checkIn . 'Pickup?' . $row->pickup . '<br>';
	}
*/
}

}


?>
