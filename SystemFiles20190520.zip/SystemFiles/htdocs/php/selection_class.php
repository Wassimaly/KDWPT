<?php
class Selection{
	//Variables
	public $itemType;
	public $checkOut;
	public $checkIn;
	public $pickup;
	public $legal = false;
	public $item;
	public $errorLog = "";
	//Constructor
	function __construct($Type, $In, $Out, $pickUp){
		$this->itemType = $Type;
		$this->checkOut = $Out;
		$this->checkIn = $In;
		$this->pickup = $pickUp;
	}
	//Save selection to session prior to submission.

}
function save_selection(bool $final){
	$itemTable = $_SESSION['itemTypeList'];
	
	//Create count
	$i = 0;
	$itemsSelected = array();
	foreach($itemTable as $row){
		//echo "Iteration " . $i . "<br>";
		
		//Save the checkbox name.
		$nameHolder = $row['itemTypeID'];
		$checkIn = 'dateIn' . $i;
		$checkOut = 'dateOut' . $i;
		$pickup = false;
		if($final){
			$pickup = $row['pickup' . $i];	
		}
		//Check if item is selected
		if(isset($_POST[$nameHolder])){ 

			//Save the item as selected with dates
			$itemsSelected[] = new Selection($row['TypeName'], $_POST[$checkIn], $_POST[$checkOut], $pickup);
			//echo $row['TypeName'] . ' saved.<br>';
		}
		$i++;


	}
	$_SESSION['Selections'] = $itemsSelected;
	
}
?>