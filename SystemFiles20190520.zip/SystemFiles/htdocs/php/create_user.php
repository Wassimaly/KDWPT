<?php

//Create Connection

require_once('../connect.php');
if(isset($_POST['submit'])){



    //Check Connection
    if($dbc->connect_error){
        die("Connection failed: " . $dbc->connect_error);
    }
//	echo 'Connection Established</p>';

    //prep and bind
    if(!get_magic_quotes_gpc()){
        $UserName = addslashes($_POST['str_UserName']);
        $Email = addslashes($_POST['str_Email']);
        $Password = addslashes($_POST['str_UserPass']);
		$vPassword = addslashes($_POST['str_UserPass']);
        $FirstName = addslashes($_POST['str_FirstName']);
        $LastName = addslashes($_POST['str_LastName']);
        $Phone = addslashes($_POST['str_Phone']);
        $County = addslashes($_POST['County']);
        $Address = addslashes($_POST['str_Address']);
        $City = addslashes($_POST['str_City']);
        $Zip = addslashes($_POST['str_Zip']);
        $Organization = addslashes($_POST['str_Organization']);
    }
    else{
        $UserName = $_POST['str_UserName'];
        $Email = $_POST['str_Email'];
        $Password = hash($_POST['str_UserPass']);

        $FirstName = $_POST['str_FirstName'];
        $LastName = $_POST['str_LastName'];
        $Phone = $_POST['str_Phone'];
        $County = $_POST['County'];
        $Address = $_POST['str_Address'];
        $City = $_POST['str_Address'];
        $Zip = $_POST['str_Zip'];
		if(isset($_POST['str_Organization'])){
			        $Organization = $_POST['str_Organization'];
		}
        else $Organization = "";
    }
	require('../php/validate_user.php');
	if(!$UserIsValid) echo "User invalid</p>";
	if($UserIsValid)
    {
		$Password = md5($Password);
        $query = "CALL NewUser('$UserName', '$Password','$Email','$FirstName','$LastName','$Phone','$County', '$Address','$City','$Zip','$Organization')";
        $retval = mysqli_query($dbc, $query);
        if(! $retval){
            die('Could not enter data: ' . mysqli_error($dbc) . '</p>');
        }
        // send email
        $msg = "We look forward to hearing from you!";
        $headers = "From: KDWPT_Email@example.com";
        mail($Email, "Thank You, " . $FirstName . ", for signing up!",$msg,$headers);

       header("location: ../pages/login_user.html.php");
        //      echo "Entered user info successfully</p>";
        mysqli_close($dbc);
    }

}
?>
<html>
<head>
    <title>KDWPT Library::Add Users Database</title>
	<?php
		include('../php/meta_loader.php');
	?>
</head>

<body>
<div id="innerbody">
<header>
    <h1>KDWPT Library: New User</h1>
</header>
		<nav>
		</nav>
<form method="post">
	<div class="container">
		<p><label for="str_UserName">User Name: </label> <input type="text" name="str_UserName" id="str_UserName"></p>
		<p><label for="str_Email">Email: </label>  <input type="email" name="str_Email" id="str_Email"></p>
		<p><label for="str_vEmail">Verify Email: </label>  <input type="email" name="str_vEmail" id="str_vEmail"></p>
		<p><label for="str_UserPass">Password: </label>  <input type="password" name="str_UserPass" id="str_UserPass"></p>
		<p><label for="str_vUserPass">Verify Password: </label>  <input type="password" name="str_vUserPass" id="str_vUserPass"></p>
		<p><label for="str_FirstNameName">First Name: </label>  <input type="text" name="str_FirstName" id="str_FirstName"></p>
		<p><label for="str_LastName">Last Name: </label>  <input type="text" name="str_LastName" id="str_LastName"></p>
		<p><label for="str_Phone">Phone: </label>  <input type="tel" name="str_Phone" id="str_Phone"></p>
		<p><label for="str_County">County: </label>
		<?php 
			@require('../connect.php');
			$table_name = "userinfo";
			$column_name = "County";

			echo "<select name='$column_name' id='str_County'>";
			
			$result = mysqli_query($dbc,"SELECT COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS
				WHERE TABLE_NAME = '$table_name' AND COLUMN_NAME = '$column_name'")
			or die (mysqli_error());

			$row = mysqli_fetch_array($result);
			$enumList = explode(",", str_replace("'", "", substr($row['COLUMN_TYPE'], 5, (strlen($row['COLUMN_TYPE'])-6))));
			$i = 1;
			foreach($enumList as $value){
				echo "<option value='$i'>$value</option>";
				$i++;
			}
			echo "</select></p>";
		?>
		<p><label for="str_Address">Address: </label><input type="text" name="str_Address" id="str_Address"></p>
		<p><label for="str_City">City: </label><input type="text" name="str_City" id="str_City"></p>
		<p><label for="str_Zip">Zip: </label><input type="text" name="str_Zip" id="str_Zip"></p>
		<p><label for="str_Organization">Organization: </label><input type="text" name="str_Organization" id="str_Organization"></p>

		<button type="submit" name="submit" id="submit">Create User</button>
        <button onclick="location.href='../pages/login_user.html.php'" type="button">
            Return to Login</button>
	</div>	
	</div>
</form>
<!--<script src="../js/checkUserFields.js"></script>-->
</body>
</html>