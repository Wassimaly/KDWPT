<?php
@session_start();
	$logout = '../pages/logout.php';
	$logoutNav = "<li><a href='$logout'>Log Out</a></li>";
	
	if($_SESSION['IsAdmin']){
		$mainpage = '../pages/admin_welcome.php';
		$mainpageNav = "<li><a href='$mainpage'>Home</a></li>";
		$reports = '../pages/reports.php';
		$reportsNav = "<li><a href='$reports'>Reports</a></li>";
		$newItems = '../pages/new_item.php';
		$editItems = '../pages/edit_item.php';
		$addItem = '../pages/copy_item.php';
		$ItemNav = "<li><div class='dropdown'> <button onclick='displayNavDrop()' class='dropbtn'>Items</button>
  <div id='myDropdown' class='dropdown-content'>
    <a href='$newItems'>Add New Item</a>
    <a href='$editItems'>Change Item Status</a>
    <a href='$addItem'>Make Copies of Item</a></div></div></li>";
		$nav = "<ul>" . $mainpageNav . $ItemNav . $reportsNav . $logoutNav . "</ul>";
	}
	else{
		$mainpage = '../pages/welcome.php';
		$mainpageNav = "<li><a href='$mainpage'>Home</a></li>";
		$accountSum = '../pages/account_summary.php';
		$accountSumNav = "<li><a href='$accountSum'>Account Summary</a></li>";
		$nav = "<ul>". $mainpageNav . $accountSumNav . $logoutNav . "</ul>";
	} 

	echo $nav;
	?>