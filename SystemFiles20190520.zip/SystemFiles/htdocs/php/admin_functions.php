<?php
//Takes items listed selected as delivered and returns them. Can be set to show all deliveries from both libraries
function updateDeliveries(bool $all){
	if(isset($_POST['library']) && !$all){
			$_SESSION['library'] = addslashes($_POST['library']);
			$library = $_SESSION['library'];
	}
	$query;
	$library = $_SESSION['library'];
	$query = "CALL GetAllReservations()";
	
	require_once('../connect.php');

	$response = mysqli_query($dbc,$query);
	if($response){
		while($row = mysqli_fetch_array($response)){
			$holder = $row['ResName'];
			if(isset($_POST[$holder])){
				$query = "CALL DeliverItem('$holder')";
				mysqli_close($dbc);
				require('../connect.php');
				mysqli_query($dbc, $query);
			}
		}
	}
	mysqli_close($dbc);
	getReservations($all);

}

function updateItemsDue(){
	if(isset($_POST['library'])){
		$_SESSION['library'] = addslashes($_POST['library']);
		$library = $_SESSION['library'];
	}

	$query = "CALL GetItemsDue('$library')";
	require('../connect.php');
	$response = mysqli_query($dbc,$query);
	if($response){
		while($row = mysqli_fetch_array($response)){
			$holder = $row['ResName'];
			//echo 'Checking reservation number ' . $holder . '<br>';
			if(isset($_POST[$holder])){
				echo $holder . ' is selected.<br>';
				$query = "CALL ReturnItem('$holder')";
				mysqli_close($dbc);
				require('../connect.php');
				mysqli_query($dbc, $query);
			}
			//else echo $holder . ' is not selected.<br>';
		}
	}
	mysqli_close($dbc);
	getItemsDue();
		
}


//Constructs table of items due.
function getItemsDue(){
	if(isset($_POST['library'])){
			$_SESSION['library'] = addslashes($_POST['library']);
			$library = $_SESSION['library'];

	$query = "CALL GetItemsDue('$library')";
	require('../connect.php');

	$response = mysqli_query($dbc,$query);
	if($response){
		//echo 'Starting response';
		$count = mysqli_num_rows($response);
		if($count == 0){
			echo 'No items due for library.<br>';
			return;
		}
		echo '<div class="container">';
		echo '<table class="searchable sortable"><thead>
		<tr><th>ReceiptID</th>
		<th>Due Date</th>
		<th>Item ID</th>
		<th>Name</th>
		<th>Address</th>
		<th>Phone Number</th>
		<th>Send email</th>
		<th>Item Returned</th>
		</tr></thead>';
		while($row = mysqli_fetch_array($response)){
			$sendEmail = 'location.href="mailto:';
			echo '<tr><td>' .
			$row['ReceiptID'] . '</td><td>' .
			$row['Due_Date'] . '</td><td>' .
			$row['Item_ID'] . '</td><td>' .
			$row['Name'] . '</td><td>' .
			$row['Address'] . '</td><td>' .
			$row['Phone_Number'] . '</td><td>' .
			'<button type="button" onclick=' . $sendEmail . $row['Email'] . ';">Send Email</button></td><td class="checkbox">' .
			'<input type="checkbox" name="' . $row['ResName'] . '"></td></tr>';
		}
		echo '</table>' . 
		'<button type="submit" name="updateItemsDue">Update Items Due</button>';
	}else{
		echo '<br>Request failed. Either no items due, or unable to complete query.<br>';
	}
	mysqli_close($dbc);
		}else echo '<br> ERROR: Library not selected.';
}


function getReservations(bool $all){
	if(isset($_POST['library']) && !$all){
			$_SESSION['library'] = addslashes($_POST['library']);
			$library = $_SESSION['library'];
	}
	$query;
	$library = $_SESSION['library'];
	if($all){
		$query = "CALL GetAllReservations()";
	}else $query = "CALL GetDeliveryTable('$library')";
	
	require('../connect.php');

	$response = @mysqli_query($dbc,$query);
	if($response){
		$count = mysqli_num_rows($response);
		if($count == 0){
			echo 'No reservations available.<br>';
			return;
		}
		echo '<table class="searchable sortable"><thead>
		<tr><th>Receipt#</th>
		<th>Checkout Date</th>
		<th>Item ID</th>
		<th>Name</th>
		<th>Address</th>
		<th>Phone Number</th>
		<th>Pickup</th>
		<th>Status</th>
		<th>Delivered</th>	
		<th>Return Date</th>		
		</tr></thead>';
		while($row = mysqli_fetch_array($response)){
			echo '<tr><td>' .
			$row['ReceiptID'] . '</td><td>' .
			$row['Checkout_Date'] . '</td><td>' .
			$row['Item_ID'] . '</td><td>' .
			$row['Name'] . '</td><td>' .
			$row['Address'] . '</td><td>' .
			$row['Phone_Number'] . '</td><td>' .
			$row['Pickup'] . '</td><td>' .
			$row['Delivered']. '</td><td class="checkbox">' .
			'<input type="checkbox" name="' . $row['ResName'] . '"></td><td>' . 
			$row['Return_Date'] . '</td></tr>';
		}
		echo '</table>' . 
		'<button type="submit" name="updateDeliveries">Update Deliveries</button>';
	}
		mysqli_close($dbc);
}
		
		
//Create items

function createItem($str_TypeName, $str_Desc, $str_Media, $str_Subject, $int_Listed){
	
	//Create Connection
	require('../connect.php');
	//Check Connection
	if($dbc->connect_error){
		die("Custom Error Line ~170: Connection failed: " . $dbc->connect_error);
	}
	

		
	$query = "CALL NewItemType('$str_TypeName', '$str_Desc', '$str_Media', '$str_Subject', '$int_Listed')";
	$retval = mysqli_query($dbc, $query);
	
	if(! $retval){
		die('Custom Error Line ~179: Could not enter data: ' . mysqli_error($dbc));
	} 
	
	mysqli_close($dbc);
	require('../connect.php');		
			
	//Check if item will be added to kit.
	if(isset($_POST['kitCheckBox'])){
		//echo 'Test Update: Checkbox checked.<br>';
		$kitQuery = "CALL GetKitNames()";
		$kitTable = mysqli_query($dbc, $kitQuery);
		
		//Check which existing kits get item and create kit relation
		while($row = @mysqli_fetch_array($kitTable)){
			$nameHolder = $row['KitName'];
			if(isset($_POST[$nameHolder])){
				mysqli_close($dbc);
				require('../connect.php');		
				$newKitRelQuery = "CALL NewKitRelation('$nameHolder','$str_TypeName')";
				$sendVal = mysqli_query($dbc, $newKitRelQuery);
				
				if(! $sendVal){
					die('Custom Error Line ~201: Could not enter data: ' . mysqli_error($dbc) . '<br>');
				}
				echo 'Item added to ' . $nameHolder . ' <br>';
			}else{
				echo $nameHolder . ' not set<br>';
			} 
		}
	mysqli_close($dbc);
	require('../connect.php');
	$output = 'Database connection established.'; 
	
	//Create new kit and add item to it.
	if(isset($_POST['addNewKit'])){
		$newKitQuery = "CALL NewKit('$KitName')";
		$makeNewKit = mysqli_query($dbc, $newKitQuery);
	
		if(! $makeNewKit){
			die('Custom Error Line ~218: Could not enter data: ' . mysqli_error($dbc) . '<br>');
		}
		echo 'New kit added.<br>';
		mysqli_close($dbc);
		
		//Add relation for new kit
		require('../connect.php');	
		$newKitRelQuery = "CALL NewKitRelation('$KitName','$str_TypeName')";
		$sendVal = mysqli_query($dbc, $newKitRelQuery);
		if(! $sendVal){
			die('Custom Error Line ~228: Could not enter data: ' . mysqli_error($dbc) . '<br>');
		}
		else{
			echo 'Item added to ' . $KitName . '<br>';
		}
	}
		/* else{
			echo 'Test Output: Add New kit checkbox not set.<br>';
		}*/
	} 
	//If checkbox not set for a kit.
	else{
		echo 'Kit checkbox not set. <br>';
	}
	
	echo 'Entered data successfully.<br>';
	mysqli_close($dbc);	
	//Begin adding items
	if(isset($_POST['addItems'])){
		if(isset($_POST['itemCount'])){
			$count = $_POST['itemCount'];
			require('../connect.php');
			$query = "SELECT itemTypeID FROM itemType WHERE TypeName = '$str_TypeName' LIMIT 1";
			$retVal = mysqli_query($dbc, $query);
			
			if(! $retVal){
				die('Custom Error Line ~254: Could not enter data: ' . mysqli_error($dbc) . '<br>');
			}
						
			if(isset($_POST['listItems'])){
				$listItems = 2;
			}else{
				$listItems = 1;
			}

			$typeID = mysqli_fetch_field($retVal);
			
			//Create as many items are requested
			for($i = '1'; $i<= $count; $i++){
				$itemID = $_POST['library'] . $str_TypeName . $i;
				echo $itemID . '<br>';
				$query = "CALL NewItem('$itemID','$str_TypeName', '$listItems')";
				require('../connect.php');
				$retVal = mysqli_query($dbc, $query);
				if(! $retVal){
					die('Custom Error Line ~272: Could not enter data on attempt ' . $i . ' : ' . mysqli_error($dbc) . '<br>');
				}
							
			}
		}
	}
}

//Add items to existing item type
function addMoreItems(int $int_thisMany, $str_itemType, $str_library, $int_Listed){
	//create variables
	$int_TypeID;
	$start_count;
	require('../connect.php');
	$query = "CALL GetTypeID('$str_itemType')";
	$results = mysqli_query($dbc, $query);
	if(!$results){
		die(mysqli_error($dbc) . '<br>');
	}

	while($row = mysqli_fetch_array($results)){
		$int_TypeID = $row['itemTypeID'];
	}
	$query = "CALL LastItemOfType('$int_TypeID', '$str_library')";
	mysqli_close($dbc);
	
	require('../connect.php');
	$results = mysqli_query($dbc, $query);
	
	while($row = mysqli_fetch_array($results)){
		$start_count = $row['Last']+1;
	}
	
	for($i = $start_count; $i < $start_count + $int_thisMany; $i++){
		mysqli_close($dbc);
		require('../connect.php');
		$newItemName = $str_library . $str_itemType . $i;
		$query = "CALL NewItem('$newItemName', '$str_itemType', '$int_Listed')";
		$results = mysqli_query($dbc, $query);
		if(!$results){
			die('Add Item failed: ' .mysqli_error($dbc) . '<br>');
		}
	}
}

function displayEditTable($ofItemType, $library){
	require('../connect.php');
	$query = "CALL GetItemsByType('$ofItemType', '$library')";
	$results = mysqli_query($dbc, $query);
	if(!$results){
		die(mysqli_error($dbc) . '<br>');
	}
	else{
		echo '<table class="searchable sortable"><thead>
		<tr><th>ItemID</th>
		<th>Available</th>
		<th>Change Availability</th>
		<th>Set Availability</th>
		<th>Listed in Catalogue</th>
		<th>Change Listed Status</th>
		<th>Set Listed Status</th>
		</tr></thead>';
		while($row = mysqli_fetch_array($results)){
			echo '<tr><td>' .
			$row['itemID'] . '</td><td>' .
			$row['ItemStatus'] . '</td>' .
			'<td class="checkbox"><input type="checkbox" name="setStatus' . $row['itemID'] . '"></td>';
			echo '<td><select name="itemStatus' . $row['itemID'] . '">' . '<option value="available">Available</option><option value"unavailable">Unavailable</option>/select></td>';
			echo '<td>'; 
			if($row['listed'] == 1) echo 'Yes';
			else echo 'No';
			echo '</td>' .
			'<td class="checkbox"><input type="checkbox" name="setListed' . $row['itemID'] . '"></td>' .
			'<td><select name="listed' . $row['itemID'] . '">' . '<option value="1">Yes</option><option value="0">No</option></select></td>';
			
			'<td class="checkbox"><input type="checkbox" name="setlisted' . $row['itemID'] . '"></td>' .
			
			'</tr>';
		}
		echo '</table>';
		}
}

function updateItemStatus(){
	
}
?>































