<?php
session_start();
require_once('../connect.php');

if($_SERVER["REQUEST_METHOD"] == "POST") {

    // username and password sent from form
    $UserName = addslashes($_POST['str_UserName']);
	
	//NOTE: MD5 is not secure. Used only as a plaeholder along with PASSWORD function for testing purposes. Replace with own hash/salting method.
    $Password = md5(addslashes($_POST['str_UserPass']));

    $query = "CALL Login('$UserName', '$Password')";
    $result = mysqli_query($dbc,$query);
 //   echo $query;

    $count = mysqli_num_rows($result);

    // If result matched $UserName and $Password, table row must be = 1 row

    if($count == 1) {
//        session_register("UserName");
        $_SESSION['login_user'] = $UserName;
		while($row = mysqli_fetch_array($result)){
			$_SESSION['UserID'] = $row['UserID'];
			$_SESSION['IsAdmin'] = $row['IsAdmin'];
			$_SESSION['FirstName'] = $row['FirstName'];
			$_SESSION['LastName'] = $row['LastName'];
		}
		//Check if user is admin and send to appropriate page
		if($_SESSION['IsAdmin'] == 1) header('Location:../pages/admin_welcome.php');
		else header("Location:../pages/welcome.php");
		


    }else {
        $error = "Your Login Name or Password is invalid";
    }
}
?>
<html>

<head>
    <title>Login Page</title>
<?php
	include('../php/meta_loader.php');
?>
</head>

<body bgcolor = "#FFFFFF">

<div id="innerbody">
<header>
	<h1>KDWPT Library Login</h1>
</header>
            <form action = "" method = "post">
			<div class="container">
                <p><label for="str_UserName">User Name:</label><input type="text" name="str_UserName" id="str_UserName"></p>
                <p><label for="str_UserName">Password:</label> <input type="password" name="str_UserPass" id="str_UserPass"></p>
               <p><div class="btnholder"><button onclick="location.href='../pages/create_account.php'" type="button">Create New User</button></div>
			   <div class="btnholder"><button type="submit" value = " Submit ">Submit</button></div></p>
			</div>
            </form>
            <div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php if (!empty($error)) {
                    echo $error;
                } ?></div>

</div>

</body>
</html>