<?php
	require('../php/check_login.php');
	isLoggedIn();
	IsAdmin();
	include('../php/admin_functions.php');
?>
<!DOCTYPE html>
<html>
	<head>
		<title>KDWPT Library::Add Items to Database</title>
		<?php
			include('../php/meta_loader.php');
		?>
	</head>

	<body>
		<div id="innerbody">
		<header>
			<h1>Change Available/Listed Items</h1>
		</header>
		<nav>
			<?php
				include('../php/default_nav.php');
			?>
		</nav>
	<form method="post">
		<div class="container">
			<p><label for="int_ItemType">Item Type:</label>
		<script src="../js/newItem.js"></script>
			<?php 
			require('../connect.php');
			$table_name = "itemType";
			$column_name = "media";

			echo "<select name='str_ItemType'>";
			$query = "Call GetItemTypes()";
			$result = mysqli_query($dbc,$query)
			or die (mysqli_error());
			
			while($row = mysqli_fetch_array($result)){
				$value =$row['ItemType'];
				$TypeID = $row['TypeID'];
				echo "<option value='$TypeID'>$value</option>";
			}
			echo "</select></p>";
		?>
		<p><label>Library:</label>
						<select name="library">
						<option value="KSL">KSL</option>
						<option value="KSC">KSC</option>
						</select></p>
		<p><button type="submit" name="submit" id="displayItems">Display Items</button>
		
		</div>
		</form>
		<?php
		if(isset($_POST['submit'])){
				echo '<form method="post">
						<div class="container">';
				$itemType = $_POST['str_ItemType'];
				$str_lib = $_POST['library'];
				displayEditTable($itemType, $str_lib);
				echo '</div></form>';
		}
	?>
		<script src="../js/navDisplay.js"></script>
	</body>
</html>