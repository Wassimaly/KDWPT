<?php
@require('../php/check_login.php');
	isLoggedIn();
	isAdmin();

?>
<!DOCTYPE html>
<html>
	<head>
	<?php
		include('../php/meta_loader.php');
	?>
	</head>
	<body>
		<div id="innerbody">
			<header>
				<h1>Library Reports</h1>
			</header>
			<nav>
				<?php
					include('../php/default_nav.php');
				?>
			</nav>
			</div>
	</body>
</html>