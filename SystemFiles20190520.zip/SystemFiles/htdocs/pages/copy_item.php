<?php
	require('../php/check_login.php');
	isLoggedIn();
	IsAdmin();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>KDWPT Library::Copy Items</title>
		<?php
			include('../php/meta_loader.php');
		?>
	</head>

	<body>
		<div id="innerbody">
		<header>
			<h1>Add Copies of Items to Library</h1>
		</header>
		<nav>
			<?php
				include('../php/default_nav.php');
			?>
		</nav>
			
	<?php
	include('../php/admin_functions.php');
	?>
	<form method="post">
		<div class="container">
			<p><label for="str_ItemType">Item Type:</label>
			<?php 
			require('../connect.php');

			echo "<select name='str_ItemType' id='str_ItemType'>";
			$query = "Call GetItemTypes()";
			$result = mysqli_query($dbc,$query)
			or die (mysqli_error());
			
			while($row = mysqli_fetch_array($result)){
				$value =$row['ItemType'];
				echo "<option value='$value'>$value</option>";
			}
			echo "</select></p>";
		?>
		<p><label for="library">Library:</label><select name="library" id="library"><option value="KSC">KSC</option><option value="KSL">KSL</option></select></p>
		<p><label for="Listed">Listed:</label><select name="itemListed" id="itemListed"><option value="1">Yes</option><option value="0">No</option></select></p>
		<p><label for="int_ItemNum">Number of items:</label><input type="number" name="int_ItemNum"></p>
		<button type="submit" name="submit">Add Items</button>
		</div>
	</form>
	<?php
		if(isset($_POST['submit'])){
			if(isset($_POST['int_ItemNum'])){
				if($_POST['int_ItemNum'] > 0){
					if(!isset($_POST['str_ItemType'])){
						die('Not set: "str_ItemType"<br>');
					}
					$itemType = $_POST['str_ItemType'];
					$listed = $_POST['itemListed'];
					$itemLibrary = $_POST['library'];
					$thisMany = $_POST['int_ItemNum'];
					addMoreItems($thisMany, $itemType, $itemLibrary, $listed);
				}
			}
		}
	?>
		<script src="../js/navDisplay.js"></script>
	</body>
</html>