<?php
	require('../php/check_login.php');
	isLoggedIn();
	IsAdmin();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>KDWPT Library::Add Items to Database</title>
		<?php
			include('../php/meta_loader.php');
		?>
	</head>

	<body>
		<div id="innerbody">
		<header>
			<h1>Add Items to Library</h1>
		</header>
		<nav>
			<?php
				include('../php/default_nav.php');
			?>
		</nav>
				<form action="NewItem" method="post">
					<div class="container">
						<p><label>Item Name:</label> <input type="text" name="str_TypeName" id="str_TypeName"></p>
						<p><label>Description:</label> <input type="text" name="str_description" id="str_description"></p>
						<p><label>Subject:</label> <input type="text" name="str_subject" id="str_subject"></p>
						<p><label>Media Type:</label>
						<?php 
			require('../connect.php');
			$table_name = "itemType";
			$column_name = "media";

			echo "<select name='str_media'>";
			$query = "Call GetMediaTypes()";
			$result = mysqli_query($dbc,$query)
			or die (mysqli_error());
			
			while($row = mysqli_fetch_array($result)){
				$value =$row['media'];
				echo "<option value='$value'>$value</option>";
			}
			echo "</select><br>";
		?>
		</p>
		<p><label>New Media:</label><input type="checkbox" name="newMedia" id="addNewMedia"></p>
		<div id="newMedia" style="display:none">
		<p><label>New Media Name:</label><input type="text" name="str_newMedia" id="str_newMedia"></p>
		</div>

		<p><label>Part of Kit?</label> <input type="checkbox" name="kitCheckBox" id="kitCheckBox"></p>
		
		<!--Hidden Section for Kit Creation -->
		<div id = "kitDiv" style="display:none">
			<?php 
				require('../connect.php');
				if($dbc->connect_error){
					die("Custom Error Line 29: Connection failed: " . $dbc->connect_error);
				}
				$kitQuery = "CALL GetKitNames()";
				mysqli_select_db($dbc, $kitQuery);
				$retKitVal = mysqli_query($dbc, $kitQuery);
				
				if($retKitVal){
					echo '
						<table>
							<tr><th>Select</th>
							<th>Kit Name</th>
						</tr>';

							while($row = @mysqli_fetch_array($retKitVal)){
								echo '<tr><td class="checkbox"><input type="checkbox" id="' .
								$row['KitID'] . '" name="' .
								$row['KitID'] . '"></td><td>' .
								$row['KitName'] . '</td></tr>';
							}
				}
					mysqli_close($dbc);
					echo '</table>';
				?>
				<p><label for="addNewKit">New Kit?</label><input type="checkbox" id="addNewKit" name="addNewKit"></p>

						<p><label for="str_KitName">Kit Name:</label><input type="text" name="str_KitName" id="str_KitName" disabled></p>


				</div>
				<p><label>Add Items to Library? </label><input type="checkbox" name="addItems" id="addItems"></p>
				<div id="instances" style="display:none">
					<p><label>No Checkout? </label><input type="checkbox" name="listItems" id="listItems"></p>
					<p><label>Number of items: </label><input type="number" name="itemCount" min="1"></p>
					<p><label>Library:</label>
						<select name="library">
						<option value="KSL">KSL</option>
						<option value="KSC">KSC</option>
						</select></p>
				</div>
				<button type="submit" name="submit">Create Item</button>
			</div>
		</form>
	<?php
	include('../php/admin_functions.php');
	if(isset($_POST['submit'])){
		if($_POST['submit'] == 'NewItem'){
			//prep and bind
		if(!get_magic_quotes_gpc()){
			$TypeName = addslashes($_POST['str_TypeName']);
			$Description = addslashes($_POST['str_description']);
			if(isset($_POST['addNewMedia'])){
			$Media = addslashes($_POST['str_newMedia']);
			}else{
			$Media = addslashes($_POST['str_media']);
			}
			$Subject = addslashes($_POST['str_subject']);
			if(isset($_POST['str_KitName'])){
			$KitName = addslashes($_POST['str_KitName']);
			}
			else{
				$KitName = "";
			}
		}
		else{
			$TypeName = $_POST['str_TypeName'];
			$Description = $_POST['str_description'];
			$Media = $_POST['str_media'];
			$Subject = $_POST['str_subject'];	
			if(isset($_POST['str_KitName'])){				
			$KitName = ($_POST['str_KitName']);		
			}else{
				$KitName = "";
			}
		}
		//Check if listed
		$Listed =0;
		if(isset($_POST['listItems'])){
			if($_POST['listItems']){
				$Listed = 1;
			}
			
		}
		if($TypeName == "" || $Description == "" || $Media == "" || $Subject == ""){
			echo 'ERROR: Item not added.';
		}else createItem($TypeName, $Description, $Media, $Subject, $Listed);
	}
	}
	?>
		<script src="../js/navDisplay.js"></script>
	</body>
</html>