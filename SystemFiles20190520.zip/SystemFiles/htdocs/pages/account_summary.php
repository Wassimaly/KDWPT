<?php
	@session_start();
	require('../php/check_login.php');
	isLoggedIn();
?>
<!DOCTYPE html>
<html>
<head>
		<title>KDWPT Library::Account Summary</title>
		<?php
			include('../php/meta_loader.php');
		?>
	</head>

	<body>
		<div id="innerbody">
		<header>
			<h1>Account Summary</h1>
		</header>
		<nav>
			<?php
				include('../php/default_nav.php');
			?>
		</nav>
		
		<h2>Current Reservations</h2>
		<form method="POST">
		<div class="container">
		<?php
			$itemsReserved = array();
			if(isset($_POST['submit'])){
				foreach($_SESSION['ItemsReserved'] as $row){
					$removeItem = 'cancel' . $row['ReservID'];
					if(isset($_POST[$removeItem])){
						require('../connect.php');
						$remove = $row['ReservID'];
						$query = "CALL DeleteReserv('$remove')";
						mysqli_query($dbc, $query);
						mysqli_close($dbc);
					}
				}
				
			}
			require('../connect.php');
			$user = $_SESSION['UserID'];
			$query = "CALL GetUserReserv('$user')";
			$results = mysqli_query($dbc, $query);
			if(!$results){
				echo "No current reservations found.<br>";
			}
			else{
				echo '<table>
				<tr><th>Item Name</th>
				<th>Check Out Date</th>
				<th>Return Date</th>
				<th>Pick Up at Library</th>
				<th>Cancel Request</th>';
				
				while($row = mysqli_fetch_array($results)){
					$itemsReserved[] = $row;
					echo '<tr>
					<td>' . $row['Item'] . '</td>' .
					'<td>' . $row['checkout'] . '</td>' .
					'<td>' . $row['checkin'] . '</td>' . 
					'<td>' . $row['pickup'] . '</td>' .
					'<td class="checkbox"><input type="checkbox" name="cancel' . $row['ReservID'] . '"></td>' .
					'</tr>';
				}
				echo '</table>';
				echo '<div class="center"><button type="submit" name="submit">Cancel Selected</button></div>';
				$_SESSION['ItemsReserved'] = $itemsReserved;
			}
			mysqli_close($dbc);
		?>
		</div>
		</form>
		<h2>Items Due</h2>
		<?php
			require('../connect.php');
			$user = $_SESSION['UserID'];
			$lib = 'KSL';
			$query = "CALL GetUserItemsDue('$lib','$user')";
			$results = mysqli_query($dbc, $query);
			if(mysqli_num_rows($results) == 0){
				echo "<div class='center'>No items currently due at the Kansas Library.</div><br>";
			}
			else{
				echo '><h3 class="center">Kansas Library</h3>
				<table>
				<tr><th>Item Name</th>
				<th>Check Out Date</th>
				<th>Return Date</th>
				<th>Return Library</th>';
				
				while($row = mysqli_fetch_array($results)){
					echo '<tr>
					<td>' . $row['Item_ID'] . '</td>' .
					'<td>' . $row['checkout'] . '</td>' .
					'<td>' . $row['Due_Date'] . '</td>' .
					'<td>' . $row['Library']. '</td>' .
					'</tr>';
				}
				echo '</table>';

			}
			mysqli_close($dbc);
			require('../connect.php');
			$user = $_SESSION['UserID'];
			$lib = 'KSC';
			$query = "CALL GetUserItemsDue('$lib','$user')";
			$results = mysqli_query($dbc, $query);
			if(!$results){
				echo "<div class='center'>No items currently due at the Kansas City Library.</div><br>";
			}
			else{
				echo '<h3 class="center">Kansas City Library</h3>
				<table>
				<tr><th>Item Name</th>
				<th>Check Out Date</th>
				<th>Return Date</th>
				<th>Return Library</th>';
				
				while($row = mysqli_fetch_array($results)){
					echo '<tr>
					<td>' . $row['Item_ID'] . '</td>' .
					'<td>' . $row['checkout'] . '</td>' .
					'<td>' . $row['Due_Date'] . '</td>' .
					'<td>' . $row['Library']. '</td>' .
					'</tr>';
				}
				echo '</table><br><br>';
			}
			mysqli_close($dbc);
		?>
		<h2>Previous Reservations</h2>
		<br><br>
		<?php
			require('../connect.php');
			$user = $_SESSION['UserID'];
			$lib = 'KSC';
			$query = "CALL GetUserOldReserv('$user')";
			$results = mysqli_query($dbc, $query);
			if(!$results){
				echo "<div class='center'>No reservation history available.</div><br>";
			}
			else{
				echo '<table>
				<tr><th>Item Name</th>
				<th>Check Out Date</th>
				<th>Return Date</th>
				<th>Return Library</th>';
				
				while($row = mysqli_fetch_array($results)){
					echo '<tr>
					<td>' . $row['Item_ID'] . '</td>' .
					'<td>' . $row['checkout'] . '</td>' .
					'<td>' . $row['Due_Date'] . '</td>' .
					'<td>' . $row['Library']. '</td>' .
					'</tr>';
				}
				echo '</table><br><br>';
			}
			mysqli_close($dbc);
		?>
		</div>
	</body>
</html>