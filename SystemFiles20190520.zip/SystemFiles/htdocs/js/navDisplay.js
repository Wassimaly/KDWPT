function displayNavDrop() {
  document.getElementById("myDropdown").classList.toggle("show");
}