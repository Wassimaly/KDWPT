function displayKits(){
	var checkBox = document.getElementById("kitCheckBox");
	var kitDiv = document.getElementById("kitDiv");
	
	if(checkBox.checked == true){
		kitDiv.style.display = "table";
	}else{
		kitDiv.style.display = "none";
	}
}

function addKit(){
	var checkBox = document.getElementById("addNewKit");
	var newKit = document.getElementById("str_KitName");
	
	newKit.disabled = !(checkBox.checked);
}
function addItems(){
	var checkBox = document.getElementById("addItems");
	var instances = document.getElementById("instances");
	
	if(checkBox.checked == true){
		instances.style.display = "";
	}else{
		instances.style.display = "none";
	}
}

function addMediaType(){
	var checkBox = document.getElementById("addNewMedia");
	var newMedia = document.getElementById("newMedia");
	
	if(checkBox.checked == true){
		newMedia.style.removeProperty('display');
	}else newMedia.style.display = "none";
}
function noSpaces(e){
	var key = e.keyCode;
    if (key == 32) {
      e.preventDefault();
    }
}


//Perform Page startup tasks
function pageStartup(){
	document.getElementById("kitCheckBox").addEventListener("click", displayKits, false);
	document.getElementById("addNewKit").addEventListener("click", addKit, false);
	document.getElementById("addItems").addEventListener("click", addItems, false);
	document.getElementById("addNewMedia").addEventListener("click", addMediaType, false);
	
	//Prevent spaces from being used for Item Type or Kit
	document.getElementById("str_KitName").addEventListener('keypress', noSpaces, false);
	document.getElementById("str_TypeName").addEventListener('keypress', noSpaces, false);
}

//addEventListener() to trigger all code
window.addEventListener("load", pageStartup, false);
