function goToCatalogue(){
	location.href="../pages/catalogue.php";
}
function pageStartup(){
	document.getElementById("toCatalogue").addEventListener("click", goToCatalogue, false);
}
window.addEventListener("load", pageStartup, false);