<?php

	$UserIsValid = true;
	$ErrorMsg = "<font color='white'>";
	//Check if username is already in use in database
	$query = @mysqli_query($dbc, "SELECT UserName FROM usertable WHERE UserName = $UserName");
	if($query){
			$ErrorMsg = $ErrorMsg . 'Username already exists.<br>';
	}
	if($UserName == "" || !ctype_alnum($UserName) || strlen($UserName) < 6){
		$ErrorMsg = $ErrorMsg . "Please enter valid username: Usernames must contain only letters and/or numbers and be at least 6 characters long.<br>";
		$UserIsValid = false;
	}

	if($Email == ""){
		$ErrorMsg = $ErrorMsg . "Please enter an email address.<br>";
		$UserIsValid = false;
	}
	//Basic check on password length
	if(strlen($Password) < 8){
		$ErrorMsg = $ErrorMsg . "Password must be at least 8 characters long.<br>";
		$UserIsValid = false;
	}
	//Check if password matches verified password
	if(isset($vPassword)){
		if($Password != $vPassword){
			$ErrorMsg = $ErrorMsg . "Passwords do not match.<br>";
			$UserIsValid = false;
		}
	}
	else{
		$UserIsValid = false;
	}
	
	if($FirstName == ""){
		$ErrorMsg = $ErrorMsg . "Please enter first name.<br>";
		$UserIsValid = false;
	}
	if($LastName == ""){
		$ErrorMsg = $ErrorMsg . "Please enter last name.<br>";
		$UserIsValid = false;
	}
	if($Phone == ""){
		$ErrorMsg = $ErrorMsg . "Please enter phone number.<br>";
		$UserIsValid = false;
	}
	if($Address == ""){
		$ErrorMsg = $ErrorMsg . "Please enter address.<br>";
		$UserIsValid = false;
	}
	if($City == ""){
		$ErrorMsg = $ErrorMsg . "Please enter city.<br>";
		$UserIsValid = false;
	}
	if($Zip == ""){
		$ErrorMsg = $ErrorMsg . "Please enter zip code.<br>";
		$UserIsValid = false;
	}
	if(!$UserIsValid) echo $ErrorMsg . "</font>";
?>