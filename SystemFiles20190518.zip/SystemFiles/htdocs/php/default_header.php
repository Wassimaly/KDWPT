<?php
	$redirect = '"../pages/login)user.html.php"';
	$header = "<a href='$redirect'>Log Out</a>";

	echo '<header>' . $header . '</header>';
?>