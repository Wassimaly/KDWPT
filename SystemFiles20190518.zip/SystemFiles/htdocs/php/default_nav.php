<?php
@session_start();
	$logout = '../pages/logout.php';
	$logoutNav = "<li><a href='$logout'>Log Out</a></li>";
	
	if($_SESSION['IsAdmin']){
		$mainpage = '../pages/admin_welcome.php';
		$mainpageNav = "<li><a href='$mainpage'>Home</a></li>";
		$addItem = '../pages/create_item.php';
		$addItemNav = "<li><a href='$addItem'>Add Items</a></li>";
		$nav = "<ul>" . $mainpageNav . $addItemNav . $logoutNav . "</ul>";
	}
	else{
		$mainpage = '../pages/welcome.php';
		$mainpageNav = "<li><a href='$mainpage'>Home</a></li>";
		$nav = "<ul>". $mainpageNav . $logoutNav . "</ul>";
	} 

	echo $nav;
	?>