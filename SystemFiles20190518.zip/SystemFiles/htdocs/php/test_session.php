<?php
		$_SESSION['login'] = true;
		$_SESSION['library'] = 'KSL';
		$_SESSION['UserID'] = '1';
?>