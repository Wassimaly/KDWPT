<?php
include('../php/selection_class.php');
@session_start();
	if(isset($_POST['submit'])){
		require_once('../connect.php');
		$library = $_SESSION['library'];
		$isAdmin = $_SESSION['IsAdmin'];
		$valid = false;
		
		//Get list of instances of items of type
		foreach($_SESSION['Selections'] as $row){
			mysqli_close($dbc);
			require('../connect.php');
			$type = $row->itemType;
			//echo $type . ', ' . $library . ', ' . $isAdmin . '<br>';
			$query = "CALL GetItemsByType('$type','$library','$isAdmin')";
			$response = mysqli_query($dbc, $query);
			//Check if any items are available for given date.
			while($item = mysqli_fetch_array($response)){
				$n = $item['itemID'];
			//	echo 'Able to find ' . $n . '<br>';
				$legalList = "CALL ItemLegalForDate('$n', '$row->checkOut', '$row->checkIn')";
				mysqli_close($dbc);
				require('../connect.php');
				$LLresponse = mysqli_query($dbc, $legalList);
				//echo 'Is ' . $n . ' legal? ';
				if(mysqli_num_rows($LLresponse) > 0){
					$valid = true;
					$row->legal = true;
					$row->item = $n;
				//	echo ' Yes.<br>';
					break 1;
				}
				//echo ' No.<br>';
			}
		}
		//Verify at least one item is being submitted before creating a new receipt
		//echo "Checking if request is valid.";
		if($valid){
			//echo "Request is valid";
			$user = $_SESSION['login_user'];
			$query = "CALL GetNewReceipt('$user')";
			mysqli_close($dbc);
			require('../connect.php');
			$response = mysqli_query($dbc, $query);
			
			if($response){
				$receipt = mysqli_fetch_array($response)[0];
			}
			else{
				//echo "Error line 37. Please contact system administrator.<br>";
			}

	/*		while ($rec = mysqli_fetch_array($response)){
				$receipt = $rec[0];
			}*/
			
			foreach($_SESSION['Selections'] as $row){
					$item = $row->item;
					$In = $row->checkIn;
					$Out =  $row->checkOut;
					
				//Only submit item if valid
				if($row->legal){
					//Check if item being picked up
					if($row->pickup) $pickup = 1;
					else $pickup = 0;
					
					//Set remaining variables
					$query = "CALL NewReservation('$item','$In', '$Out', $pickup, $receipt)";
					mysqli_close($dbc);
					require('../connect.php');
					$response = mysqli_query($dbc,$query);
					if(!$response){
						$row->errorLog = 'An error occured when attempting to reserve ' . $item . ' between ' . $In . ' and ' . $Out . '.';
					}
				}
				else{
					$row->errorLog = 'Unable to reserve ' . $item . ' between ' . $In . ' and ' . $Out . '.';
				}
			}
		}else {
			foreach($_SESSION['Selections'] as $row){
				$row->errorLog = 'ERROR: Unable to reserve ' . $row->itemType . ' between ' . $row->checkOut . ' and ' . $row->checkIn . '.';
			}
		}
		mysqli_close($dbc);
		if($valid){
		header('location:../pages/checkout_summary.php');
		}
	}
?>

<!DOCTYPE html>
<html>
	<head>
		
		<?php 
			include('../php/meta_loader.php');
		?>
	</head>
	<body>
	<div id="innerbody">
		<header>
				<h1>Selection Summary</h1>
		</header>
		<nav>
			<?php
				include('../php/default_nav.php');
			?>
		</nav>
		<main>
			<div class="container">
				<form method="post">
				<table class="searchable sortable"><thead>
				<tr><th>Item</th>
				<th> Check Out Date </th>
				<th> Return Date </th>
				<th> Pick Up </th>
				<?php

				foreach($_SESSION['Selections'] as $row){
					echo '<tr><td>' .
					$row->itemType . '</td><td>' .
					$row->checkOut . '</td><td>' .
					$row->checkIn . '</td><td>';
					if($row->pickup){
						echo 'Yes';
					}else{
						echo 'No';
					}
					echo '</td>';
					}
				?>
				</table>
				<p><button type="submit" id="submit" name="submit">Submit Selections</button><button type="button" id="toCatalogue">Return to Catalogue</button></p>
				</form>
				<div class="FailedReserv">
				<?php
					foreach($_SESSION['Selections'] as $row){
						echo '<br>' .$row->errorLog . '<br>';
					}
				?>
				</div>
			</div>
		</main>
	</div>
	<script src="../js/checkout.js"></script>
	</body>
</html>