<?php
	@session_start();
	$helper = array_keys($_SESSION);
	foreach($helper as $key){
		unset($_SESSION[$key]);
	}
	session_destroy();

	//Send the user to the login page.
	header('Location:../pages/login_user.html.php');
?>