<?php
@session_start();
@include('../php/admin_functions.php');
	//Verify user is allowd to view page.
	if($_SESSION['IsAdmin'] != 1) header('Location:../pages/403.html');

?>



<!DOCTYPE html>
<html>
	<head>
	<?php
			include('../php/meta_loader.php');
	?>
	</head>
	<body>
	<div id="innerbody">
		<header>
			<h1>KDWPT Library</h1>
		</header>
		<nav>
			<?php
				include('../php/default_nav.php');
			?>
		</nav>
		<form method="post">
		
				<p><input type="radio" name="library" id="KSL" value="KSL"
				<?php
					if(isset($_POST['library'])){
						if($_POST['library']== 'KSL') echo 'checked';
					}
				?>
				><label>KDWPT State Library</label></p>
				<p><input type="radio" name="library" id="KSC" value="KSC"
				<?php
					if(isset($_POST['library'])){
						if($_POST['library']== 'KSC') echo 'checked';
					}
				?>
				><label>KDWPT Kansas City Library</label></p><br><br>

				<p><button type="submit" name="showReserv">Show Reservations</button></p><p><input type="checkbox" name="allReserv" id="allReserv"><label for="allReserv">Show all</label><p><br>
				<p><button type="submit" name="showDue">Show Items Due</button></p>
		<?php
			//Check which button was pressed.
			if(isset($_POST['showReserv'])){
				
				$check = isset($_POST['allReserv']);
				getReservations($check);
			}
			
			if(isset($_POST['showDue'])){
					getItemsDue();
			}
			if(isset($_POST['updateDeliveries'])){
				$check = isset($_POST['allReserv']);
				updateDeliveries($check);
			}
			if(isset($_POST['updateItemsDue'])){
				updateItemsDue();
			}
		?>
		</div>
		</form>
	</body>
</html>

