<!DOCTYPE html>
<html>
	<head>
		<title>KDWPT::Library Catalogue</title>
		<?php
			@session_start();
			if(!isset($_SESSION['login_user'])){
				header('Location:../pages/login_user.html.php');
				return;
			}
			include('../php/meta_loader.php');
		?>
	</head>
	<body>
	<div id="innerbody">
	<header>
		<h1>
		<?php
			if($_SESSION['library'] == 'KSC') echo 'Kansas City Library';
			else echo 'Kansas Library';
		?>
		Catalogue</h1>
	</header>
	<nav>
		<?php
			include('../php/default_nav.php');
		?>
	</nav>
	<form method="post">
	<?php
		//Test variable: Comment out on when not testing
		//require_once('../php/test_session.php');
		//If the user isn't logged in, boot them back to the login page.
		if(!isset($_SESSION['UserID'])){
			header("Location:login_user.html.php");
		}
		else{
			require_once('../php/display_catalogue.php');
			create_table();
		}
	?>
	<script src="../js/checkDates.js"></script>
	</div>
	</body>
</html>