<?php

@session_start();
function isLoggedIn(){
	if(!isset($_SESSION['login_user'])){
		header('location:../pages/login_user.html.php');
		}
}

function isAdmin(){
	if($_SESSION['IsAdmin'] != 1){
		header('location:../pages/login_user.html.php');
		}
}
?>