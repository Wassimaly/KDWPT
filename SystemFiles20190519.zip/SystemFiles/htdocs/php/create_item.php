<!DOCTYPE html>
<html>
	<head>
		<title>KDWPT Library::Add Items to Database</title>
		<?php
			session_start();
			include('../php/admin_functions.php');
			include('../php/meta_loader.php');
		?>
	</head>

	<body>
		<div id="innerbody">
		<header>
			<h1>Add Items to Library</h1>
		</header>
		<nav>
			<?php
				include('../php/default_nav.php');
			?>
		</nav>
				<form method="post">
					<div class="container">
						<p><label>Item Name:</label> <input type="text" name="str_TypeName" id="str_TypeName"></p>
						<p><label>Description:</label> <input type="text" name="str_description" id="str_description"></p>
						<p><label>Subject:</label> <input type="text" name="str_subject" id="str_subject"></p>
						<p><label>Media Type:</label>
						<?php 
			require('../connect.php');
			$table_name = "itemType";
			$column_name = "media";

			echo "<select name='str_media'>";
			$query = "Call GetMediaTypes()";
			$result = mysqli_query($dbc,$query)
			or die (mysqli_error());
			
			while($row = mysqli_fetch_array($result)){
				$value =$row['media'];
				echo "<option value='$value'>$value</option>";
			}
			echo "</select><br>";
		?>
		</p>
		<p><label>New Media:</label><input type="checkbox" name="newMedia" id="newMedia"></p>
		<p><label>New Media Name:</label><input type="text" name="str_newMedia" id="str_newMedia"></p>

		<p><label>Part of Kit?</label> <input type="checkbox" name="kitCheckBox" id="kitCheckBox"></p>
		
		<!--Hidden Section for Kit Creation -->
		<div id = "kitDiv" style="display:none">
			<?php 
				require_once('../connect.php');
				if($dbc->connect_error){
					die("Custom Error Line 29: Connection failed: " . $dbc->connect_error);
				}
				$kitQuery = "CALL GetKitName()";
				mysqli_select_db($dbc, $kitQuery);
				$retKitVal = mysqli_query($dbc, $kitQuery);
				
				if($retKitVal){
					echo '<table class="subtable">
						<tr>
							<th>Select</th>
							<th>Kit Name</th>
						</tr>';

							while($row = @mysqli_fetch_array($retKitVal)){
								echo '<tr><td><input type="checkbox" id="' .
								$row['KitID'] . '" name="' .
								$row['KitID'] . '"></td><td>' .
								$row['KitName'] . '</td></tr>';
							}
				}
					mysqli_close($dbc);
				?>
				</table><p class="clear">
				
				New Kit? <input type="checkbox" id="addNewKit" name="addNewKit"><br>
				<div class="container">
					<div id="newKit" style="display:none">
						Kit Name: <input type="text" name="str_KitName" id="str_KitName"><br><br>
					</div>
				</div>

				</div>
				<label>Add Items to Library? </label><input type="checkbox" name="addItems" id="addItems"><br>
				<div id="instances" style="display:none">
					<label>Not Listed for Checkout? </label><input type="checkbox" name="listItems" id="listItems"><br>
					<label>Number of items: </label><input type="number" name="itemCount" min="1"><br>
					<label>Library:</label>
						<select name="library">
						<option value="KS">KS</option>
						<option value="KCS">KCS</option>
						</select><br>
				</div>
				<button type="submit" name="submit" id="submit">Create Item</button>
			</div>
		</form>
	</div>
	<?php

		if(isset($_POST['submit'])){
				//prep and bind
			if(!get_magic_quotes_gpc()){
				$TypeName = addslashes($_POST['str_TypeName']);
				$Description = addslashes($_POST['str_description']);
				$Media = addslashes($_POST['str_media']);
				$Subject = addslashes($_POST['str_subject']);
				$KitName = addslashes($_POST['str_KitName']);
			}
			else{
				$TypeName = $_POST['str_TypeName'];
				$Description = $_POST['str_description'];
				$Media = $_POST['str_media'];
				$Subject = $_POST['str_subject'];			
				$KitName = addslashes($_POST['str_KitName']);				
			}
			//Check if listed
			$Listed;
			if(isset($_POST['listItems'])){
				if($_POST['listItems']){
					$Listed = 0;
				}
				else $Listed = 1;
				
			}
			createItem();
		}
		
	?>

		<script src="../js/newItem.js"></script>
	</body>
</html>