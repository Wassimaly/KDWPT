<?php
	echo'<link rel="stylesheet" href="../css/default.css">'
?>