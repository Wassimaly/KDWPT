<?php
include_once('../php/display_catalogue.php');
include_once('../php/selection_class.php');
@session_start();
	//Check if selection changed, and if so, record changes to item selections.
	@require('../php/check_login.php');
	isLoggedIn();
	 if(isset($_POST['submit'])){

		foreach($_SESSION['Selections'] as $row){
			if(!isset($_POST[$row->itemType])) {
				echo $row->itemType . " is not selected.<br>";
				unset($_SESSION['Selections'][array_search($row,$_SESSION['Selections'])]);

			}
			else{
				echo $row->itemType . ' is selected.<br>';
				$checkbox = 'pickup' . $row->itemType;
				if(isset($_POST[$checkbox])) $row->pickup = true;
			}
		}
		header('Location:../pages/Selection_Summary.php');
	}
	
?>
<!DOCTYPE html>
<html>
	<head>
	<?php
			include('../php/meta_loader.php');
	?>
	</head>
	<body>
	<div id="innerbody">
		<main>
			<header>
			<h1>Verify Selection</h1>
			</header>
			<nav>
			<?php
			include('../php/default_nav.php');
			?>
			</nav>
			<div class="container">
				<form method="post">
				<table class="searchable sortable"><thead>
				<tr><th>Item</th>
				<th> Check Out Date </th>
				<th> Check In Date </th>
				<th>Pick Up at Library?</th>
				<th> Check Out?</th>
				<?php
				@session_start();

				//Build the table
				foreach($_SESSION['Selections'] as $row){
					echo '<tr><td>' .
					$row->itemType . '</td><td>' .
					$row->checkOut . '</td><td>' .
					$row->checkIn . '</td><td class="checkbox">';
					echo '<input type="checkbox" name="pickup' . $row->itemType . '"></td><td class="checkbox">';
					echo '<input type="checkbox" name="' .
					$row->itemType . '" checked></td>';
					}
				?>
				</table>
				<button type="submit" id="submit" name="submit">Verify Selections</button>
				<form>
			</div>
		</main>
	</div>
	</body>
</html>