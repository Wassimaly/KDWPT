<?php
@require('../php/check_login.php');
isLoggedIn();
?>
<!DOCTYPE html>
<html>
	<head>
		<?php
			require_once('../php/selection_class.php');
			@session_start();
			include('../php/meta_loader.php');
		?>
	</head>
	<body>
	<div id="innerbody">
		<header>
		<h1>Checkout Summary</h1>
		</header>
		<nav>
		<?php
			include('../php/default_nav.php');
		?>
		</nav>
		<main>
			<div class="container">
				<table class="searchable sortable"><thead>
				<tr><th>Item</th>
				<th> Check Out Date </th>
				<th> Return Date </th>
				<th> Pick Up </th>
				<th>Validated</th>
				<?php

				foreach($_SESSION['Selections'] as $row){
					echo '<tr><td>' .
					$row->itemType . '</td><td>';
					if($row->errorLog != ""){
						echo "ERROR</td><td>ERROR</td><td>";
						echo $row->errorLog . '</td><td>ERROR';
					}
					else{
						echo $row->checkOut . '</td><td>' .
						$row->checkIn . '</td><td>';
						if($row->pickup){
							echo 'Yes';
						}else{
							echo 'No';
						}
						echo '</td><td>Success</td>';
						}
				}
					
				?>
				</table>
				<button id="toCatalogue">Return to Catalogue</button>
			</div>
		</main>
	</div>
	<script src="../js/checkout.js"></script>
	</body>
</html>