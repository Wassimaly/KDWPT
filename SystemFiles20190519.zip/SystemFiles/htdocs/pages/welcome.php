<?php
session_start();
	@require('../php/check_login.php');
	isLoggedIn();
	if(isset($_POST['submit'])){
		if(isset($_POST['library'])){
			$_SESSION['library'] = addslashes($_POST['library']);
			$library = $_SESSION['library'];
			header("Location:../pages/catalogue.php");

		}

	}
?>
<!--Build page:-->
<!DOCTYPE html>
<html>
	<head>
	<?php
			include('../php/meta_loader.php');
	?>
	</head>
	<body>
	<div id="innerbody">
		<header>
		<h1>KDWPT Library</h1>
		</header>
		<nav>
		<?php
			include('../php/default_nav.php');
		?>
		</nav>
		
			<?php
				$user = $_SESSION['FirstName'];
				echo "Welcome, " . $user .".<br><br> Please select a library to use";
			?>
			<form method="post">
				<p><input type="radio" name="library" id="KSL" value="KSL"><label>KDWPT State Library</label></p>
				<p><input type="radio" name="library" id="KSC" value="KSC"><label>KDWPT Kansas City Library</label></p><br><br>

				<div id="KCLib" style="display:none; color:red; text-align:center"><strong>Important! The Kansas City Library does not provide shipping. If your address is outside the Kansas City Library delivery range, you will be expected to either pick up your requested items in person, or make arrangements for its pickup.</strong></div><br> <div class="notice">Please note: items checked out <em>must</em> be returned to their associated library. Neither the State Library nor the Kansas City Library will accept items owned by its sister library.</div><br>
				<input type="checkbox" name="agree" id="agree"> I have read, understood, and agree to abide by these terms.<br><br>
				<input type="submit" id = "submit" name="submit" disabled="disabled">
			</form>
		</div>
		<script src="../js/welcome.js"></script>
	</body>
</html>